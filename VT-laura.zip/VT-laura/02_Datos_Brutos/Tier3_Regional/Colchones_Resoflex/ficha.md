# Ficha VT: Colchones Resoflex

**Fecha captura:** 2026-06-25  
**Tier:** 3 | **Ranking La Nota:** 39 | **Estado:** basico

## Identificación
- **Grupo:** Independiente
- **URL:** 

## Crédito
- **Crédito propio:** No
- **Producto:** Financiación aliado
- **Modelo:** F
- **Aliados:** Sistecredito

## Condiciones
- **Canales:** Web/tienda
- **Plazos:** Por validar
- **Tasa:** Según aliado
- **Cuota inicial:** Por validar
- **Monto máximo:** Por validar

## Scoring VT
- **Índice compuesto:** 2.0/5.0

## Notas
Ficha básica sectorial